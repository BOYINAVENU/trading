"""Trading execution engine - buy and sell tokens on QuickSwap"""
from web3 import Web3
from datetime import datetime
import time

class TradingEngine:
    """Handle all buy/sell operations"""
    
    def __init__(self, config, logger, w3):
        self.config = config
        self.logger = logger
        self.w3 = w3
        self.account = w3.eth.account.from_key(config.wallet_private_key)
        
        # Router interface for QuickSwap
        self.router_interface = [
            {"inputs": [{"type": "uint256", "name": "amountOutMin"}, {"type": "address[]", "name": "path"}, 
              {"type": "address", "name": "to"}, {"type": "uint256", "name": "deadline"}],
             "name": "swapExactETHForTokens", "outputs": [{"type": "uint256[]", "name": "amounts"}],
             "stateMutability": "payable", "type": "function"},
            {"inputs": [{"type": "uint256", "name": "amountIn"}, {"type": "address[]", "name": "path"}],
             "name": "getAmountsOut", "outputs": [{"type": "uint256[]", "name": "amounts"}],
             "stateMutability": "view", "type": "function"}
        ]
    
    async def buy_token(self, token_info, balance_matic):
        """Buy tokens with MATIC"""
        try:
            # Calculate how much to spend
            spend_amount = balance_matic * (self.config.position_size_percent / 100)
            
            self.logger.info(f"\n{'='*60}")
            self.logger.trade(f"BUY SETUP: {token_info['symbol']}")
            self.logger.info(f"Spending: {spend_amount:.4f} MATIC")
            
            # Get quote
            tokens_expected = self.get_buy_quote(spend_amount, token_info['address'])
            if tokens_expected == 0:
                self.logger.error("Quote failed - cannot buy")
                return None
            
            self.logger.info(f"Expecting: ~{tokens_expected:.2f} tokens")
            
            # Calculate minimum with slippage
            min_tokens = tokens_expected * (1 - self.config.max_slippage_percent / 100)
            
            buy_info = {
                'side': 'buy',
                'token_address': token_info['address'],
                'token_symbol': token_info['symbol'],
                'amount_matic': spend_amount,
                'expected_tokens': tokens_expected,
                'min_tokens': min_tokens
            }
            
            self.logger.log_trade_execution(buy_info)
            
            # Execute
            if self.config.is_paper_trading():
                return self.simulate_buy(buy_info, token_info)
            else:
                return await self.execute_buy_live(buy_info)
                
        except Exception as e:
            self.logger.error(f"Buy failed: {e}")
            return None
    
    async def sell_token(self, position_info):
        """Sell tokens for MATIC"""
        try:
            self.logger.info(f"\n{'='*60}")
            self.logger.trade(f"SELL SETUP: {position_info['token_symbol']}")
            self.logger.info(f"Selling: {position_info['token_amount']:.2f} tokens")
            
            # Get quote
            matic_expected = self.get_sell_quote(
                position_info['token_amount'],
                position_info['token_address'],
                position_info['decimals']
            )
            
            if matic_expected == 0:
                self.logger.error("Quote failed - cannot sell")
                return None
            
            self.logger.info(f"Expecting: ~{matic_expected:.4f} MATIC")
            
            min_matic = matic_expected * (1 - self.config.max_slippage_percent / 100)
            
            sell_info = {
                'side': 'sell',
                'token_address': position_info['token_address'],
                'token_symbol': position_info['token_symbol'],
                'token_amount': position_info['token_amount'],
                'expected_matic': matic_expected,
                'min_matic': min_matic,
                'decimals': position_info['decimals']
            }
            
            self.logger.log_trade_execution(sell_info)
            
            if self.config.is_paper_trading():
                return self.simulate_sell(sell_info, position_info)
            else:
                return await self.execute_sell_live(sell_info)
                
        except Exception as e:
            self.logger.error(f"Sell failed: {e}")
            return None
    
    def get_buy_quote(self, matic_in, token_address):
        """Get expected tokens from router"""
        try:
            router = self.w3.eth.contract(
                address=Web3.to_checksum_address(self.config.quickswap_router),
                abi=self.router_interface
            )
            
            swap_path = [
                Web3.to_checksum_address(self.config.wmatic_address),
                Web3.to_checksum_address(token_address)
            ]
            
            matic_wei = self.w3.to_wei(matic_in, 'ether')
            quote = router.functions.getAmountsOut(matic_wei, swap_path).call()
            
            return float(quote[1])
        except:
            return 0
    
    def get_sell_quote(self, token_amount, token_address, decimals):
        """Get expected MATIC from router"""
        try:
            router = self.w3.eth.contract(
                address=Web3.to_checksum_address(self.config.quickswap_router),
                abi=self.router_interface
            )
            
            swap_path = [
                Web3.to_checksum_address(token_address),
                Web3.to_checksum_address(self.config.wmatic_address)
            ]
            
            token_wei = int(token_amount * (10 ** decimals))
            quote = router.functions.getAmountsOut(token_wei, swap_path).call()
            
            return float(self.w3.from_wei(quote[1], 'ether'))
        except:
            return 0
    
    def simulate_buy(self, buy_info, token_info):
        """Paper trade buy"""
        self.logger.warning("PAPER TRADE - Not executed on chain")
        return {
            'success': True,
            'tx_hash': '0xPAPERTRADE' + '0' * 50,
            'gas_used': 0,
            'token_amount': buy_info['expected_tokens'],
            'entry_price': self.calc_token_price(token_info),
            'timestamp': datetime.now(),
            'is_paper': True
        }
    
    def simulate_sell(self, sell_info, position_info):
        """Paper trade sell"""
        self.logger.warning("PAPER TRADE - Not executed on chain")
        
        current_price = position_info.get('current_price', position_info['entry_price'])
        
        return {
            'success': True,
            'tx_hash': '0xPAPERTRADE' + '0' * 50,
            'gas_used': 0,
            'matic_received': sell_info['expected_matic'],
            'exit_price': current_price,
            'timestamp': datetime.now(),
            'is_paper': True
        }
    
    async def execute_buy_live(self, buy_info):
        """Execute real buy on blockchain"""
        try:
            self.logger.warning("⚠️  LIVE TRADING - Real transaction!")
            
            router = self.w3.eth.contract(
                address=Web3.to_checksum_address(self.config.quickswap_router),
                abi=self.router_interface
            )
            
            swap_path = [
                Web3.to_checksum_address(self.config.wmatic_address),
                Web3.to_checksum_address(buy_info['token_address'])
            ]
            
            matic_value = self.w3.to_wei(buy_info['amount_matic'], 'ether')
            min_out = int(buy_info['min_tokens'])
            deadline_time = int(time.time()) + 300  # 5 min deadline
            
            # Build transaction
            tx_params = {
                'from': self.account.address,
                'value': matic_value,
                'gas': self.config.gas_limit,
                'gasPrice': self.w3.to_wei(self.config.gas_price_gwei, 'gwei'),
                'nonce': self.w3.eth.get_transaction_count(self.account.address)
            }
            
            transaction = router.functions.swapExactETHForTokens(
                min_out, swap_path, self.account.address, deadline_time
            ).build_transaction(tx_params)
            
            # Sign
            signed = self.account.sign_transaction(transaction)
            
            # Send
            tx_hash = self.w3.eth.send_raw_transaction(signed.rawTransaction)
            self.logger.info(f"TX sent: {tx_hash.hex()}")
            
            # Wait for receipt
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
            
            if receipt['status'] == 1:
                return {
                    'success': True,
                    'tx_hash': tx_hash.hex(),
                    'gas_used': receipt['gasUsed'],
                    'timestamp': datetime.now(),
                    'is_paper': False
                }
            else:
                return {'success': False, 'error': 'TX reverted'}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    async def execute_sell_live(self, sell_info):
        """Execute real sell on blockchain"""
        # Similar to buy but requires token approval first
        self.logger.error("Live sell not yet implemented - use paper trading mode")
        return {'success': False, 'error': 'Not implemented'}
    
    def calc_token_price(self, token_info):
        """Calculate current token price in MATIC"""
        try:
            token_res = token_info.get('token_reserve', 0)
            quote_res = token_info.get('quote_reserve', 0)
            decimals = token_info.get('decimals', 18)
            
            if token_res == 0:
                return 0
            
            price = (quote_res / 1e18) / (token_res / (10 ** decimals))
            return price
        except:
            return 0
    
    def get_wallet_balance(self):
        """Get current MATIC balance"""
        try:
            balance_wei = self.w3.eth.get_balance(self.account.address)
            return float(self.w3.from_wei(balance_wei, 'ether'))
        except:
            return 0
