@echo off
echo ================================================================================
echo MEMECOIN SNIPER BOT - SETUP SCRIPT
echo ================================================================================
echo.

REM Check Python installation
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.9 or higher from python.org
    pause
    exit /b 1
)

echo [1/4] Python found
python --version

REM Create virtual environment
echo.
echo [2/4] Creating virtual environment...
if exist venv (
    echo Removing old venv...
    rmdir /s /q venv
)
python -m venv venv
if errorlevel 1 (
    echo ERROR: Failed to create virtual environment
    pause
    exit /b 1
)

REM Activate virtual environment
echo.
echo [3/4] Installing dependencies...
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

REM Create config from example if not exists
echo.
echo [4/4] Setting up configuration...
if not exist config.json (
    echo config.json not found - using template
    echo.
    echo ================================================================================
    echo IMPORTANT: Edit config.json and add:
    echo   - Your private key
    echo   - Your wallet address
    echo   - Your Alchemy API key
    echo ================================================================================
) else (
    echo config.json found
)

REM Create logs directory
if not exist logs mkdir logs

echo.
echo ================================================================================
echo SETUP COMPLETE!
echo ================================================================================
echo.
echo Next steps:
echo 1. Edit config.json with your settings
echo 2. Set mode to "paper" for testing
echo 3. Run: python bot.py
echo.
echo For first-time setup, read README.md
echo ================================================================================
pause
