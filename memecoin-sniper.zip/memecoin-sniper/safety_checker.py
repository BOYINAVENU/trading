"""Safety checker - honeypot detection and contract analysis"""
from web3 import Web3
import re

class SafetyChecker:
    """Check token contracts for safety issues"""
    
    def __init__(self, config, logger, w3):
        self.config = config
        self.logger = logger
        self.w3 = w3
        
        # Dangerous function signatures
        self.dangerous_functions = {
            'mint': ['mint(', 'mintToken', '_mint'],
            'blacklist': ['blacklist', 'addBlacklist', 'isBlacklisted'],
            'pause': ['pause(', 'pauseTrading'],
            'setMaxTx': ['setMaxTxAmount', 'setMaxWalletAmount']
        }
    
    async def check_token_safety(self, token_data):
        """Run all safety checks on a token"""
        safety_score = 100
        issues = []
        
        try:
            # 1. Check contract code for dangerous functions
            if self.config.check_mint_function or self.config.check_blacklist_function:
                code_issues, code_score = await self._check_contract_code(token_data['address'])
                safety_score -= (100 - code_score)
                issues.extend(code_issues)
            
            # 2. Check liquidity
            liquidity_ok, liq_msg = self._check_liquidity(token_data)
            if not liquidity_ok:
                safety_score -= 30
                issues.append(liq_msg)
            
            # 3. Simulate buy/sell to detect honeypot
            if self.config.check_honeypot:
                is_honeypot, hp_msg = await self._check_honeypot(token_data)
                if is_honeypot:
                    safety_score -= 50
                    issues.append(hp_msg)
            
            # 4. Check holder distribution
            # (Placeholder - requires indexer or API)
            
            return {
                'safe': safety_score >= 50,
                'score': max(0, safety_score),
                'issues': issues
            }
            
        except Exception as e:
            self.logger.error(f"Safety check error: {e}")
            return {'safe': False, 'score': 0, 'issues': [f'Safety check failed: {str(e)}']}
    
    async def _check_contract_code(self, token_address):
        """Check contract bytecode for dangerous functions"""
        issues = []
        score = 100
        
        try:
            # Get contract bytecode
            code = self.w3.eth.get_code(Web3.to_checksum_address(token_address))
            code_hex = code.hex()
            
            # Check for mint function
            if self.config.check_mint_function:
                if any(sig in code_hex for sig in ['40c10f19', '1249c58b']):  # mint function selectors
                    issues.append("❌ Contract has mint function - can create unlimited tokens")
                    score -= 40
            
            # Check for blacklist function
            if self.config.check_blacklist_function:
                if any(sig in code_hex for sig in ['f9f92be4', '0ecb93c0']):  # blacklist selectors
                    issues.append("❌ Contract has blacklist function - can block sells")
                    score -= 40
            
            # Check for pause function
            if '8456cb59' in code_hex:  # pause function selector
                issues.append("⚠️  Contract can be paused")
                score -= 20
            
            return issues, score
            
        except Exception as e:
            self.logger.debug(f"Code check error: {e}")
            return ["⚠️  Could not verify contract code"], 80
    
    def _check_liquidity(self, token_data):
        """Check if liquidity is within acceptable range"""
        liquidity = token_data.get('liquidity_usd', 0)
        
        if liquidity < self.config.min_liquidity_usd:
            return False, f"❌ Liquidity too low: ${liquidity:,.0f} < ${self.config.min_liquidity_usd:,.0f}"
        
        if liquidity > self.config.max_liquidity_usd:
            return False, f"❌ Liquidity too high: ${liquidity:,.0f} > ${self.config.max_liquidity_usd:,.0f}"
        
        return True, "✓ Liquidity OK"
    
    async def _check_honeypot(self, token_data):
        """Simulate buy/sell to detect honeypot"""
        try:
            # This is a simplified check
            # Full implementation would:
            # 1. Simulate a small buy transaction
            # 2. Simulate selling those tokens
            # 3. Check if sell succeeds and returns reasonable amount
            
            # For now, check basic indicators
            token_address = token_data['address']
            
            # Check if we can get token balance (basic check)
            erc20_abi = [
                {"constant": True, "inputs": [{"name": "_owner", "type": "address"}],
                 "name": "balanceOf", "outputs": [{"name": "balance", "type": "uint256"}],
                 "type": "function"}
            ]
            
            contract = self.w3.eth.contract(
                address=Web3.to_checksum_address(token_address),
                abi=erc20_abi
            )
            
            # Try to call balanceOf for a random address
            test_address = "0x0000000000000000000000000000000000000001"
            balance = contract.functions.balanceOf(test_address).call()
            
            # If this fails or behaves strangely, might be honeypot
            return False, "✓ Basic honeypot check passed"
            
        except Exception as e:
            return True, f"❌ Potential honeypot - balanceOf call failed: {str(e)[:50]}"
    
    async def check_tax(self, token_data):
        """Check buy/sell tax (requires simulation or router analysis)"""
        # This is complex and requires either:
        # 1. Analyzing router functions
        # 2. Calling a honeypot checker API
        # 3. Simulating actual buy/sell
        
        # Placeholder implementation
        return {
            'buy_tax': 0,
            'sell_tax': 0,
            'tax_ok': True
        }
    
    async def verify_ownership_renounced(self, token_address):
        """Check if contract ownership is renounced"""
        try:
            # Common owner() function selector: 0x8da5cb5b
            owner_abi = [
                {"constant": True, "inputs": [], "name": "owner",
                 "outputs": [{"name": "", "type": "address"}], "type": "function"}
            ]
            
            contract = self.w3.eth.contract(
                address=Web3.to_checksum_address(token_address),
                abi=owner_abi
            )
            
            owner = contract.functions.owner().call()
            
            # Check if owner is zero address (renounced)
            zero_address = "0x0000000000000000000000000000000000000000"
            if owner.lower() == zero_address:
                return True, "✓ Ownership renounced"
            else:
                return False, f"⚠️  Owner: {owner}"
                
        except:
            return None, "⚠️  Could not verify ownership"
    
    def calculate_risk_score(self, safety_result, token_data):
        """Calculate overall risk score"""
        base_score = safety_result['score']
        
        # Adjust based on liquidity
        liquidity = token_data.get('liquidity_usd', 0)
        if liquidity > 10000:
            base_score += 10
        elif liquidity < 2000:
            base_score -= 10
        
        # Adjust based on age
        age = token_data.get('age_seconds', 0)
        if age > 300:  # More than 5 minutes old
            base_score += 5
        
        return min(100, max(0, base_score))
