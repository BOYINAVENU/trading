# 🚀 Memecoin Sniper Bot - Polygon Edition

**High-risk, high-reward automated memecoin trading bot for Polygon network**

Automatically detect newly launched tokens, analyze safety and potential, and execute trades with aggressive profit targets.

---

## ⚠️ **CRITICAL WARNINGS**

- **HIGH RISK**: Memecoin trading is extremely risky. Most memecoins go to zero.
- **Start Small**: Use only money you can afford to lose completely ($10-20 recommended).
- **Paper Trade First**: Always test in paper trading mode before live trading.
- **No Guarantees**: This bot can lose money. Past performance doesn't predict future results.
- **Do Your Research**: Understand how the bot works before using real money.

---

## 🎯 **Features**

### **Detection & Scanning**
- ✅ Real-time monitoring of new token pairs on QuickSwap
- ✅ Scans every 10-20 seconds for fresh launches
- ✅ Filters by liquidity range ($1K - $100K)
- ✅ Age filtering (2-10 minutes old)

### **Safety Checks**
- ✅ Honeypot detection
- ✅ Scans for mint functions (unlimited supply)
- ✅ Checks for blacklist functions
- ✅ Liquidity verification
- ✅ Contract code analysis

### **Scoring System**
- ✅ Liquidity score (0-20 points)
- ✅ Age score (0-15 points)
- ✅ Volume score (0-20 points)
- ✅ Price momentum score (0-15 points)
- ✅ Safety score (0-30 points)
- ✅ Total score threshold (default: 70/100)

### **Trading Strategy**
- ✅ Auto-buy when score exceeds threshold
- ✅ Position sizing: 10-30% of wallet per trade
- ✅ Max slippage protection (15% default)
- ✅ Multiple profit targets: 3x, 5x, 10x
- ✅ Trailing stop loss (20% from peak)
- ✅ Max hold time protection (60 min default)

### **Risk Management**
- ✅ Position size limits
- ✅ Slippage protection
- ✅ Automatic stop losses
- ✅ Max hold time limits
- ✅ Safety scoring before entry

### **Modes**
- ✅ Paper trading (simulation)
- ✅ Live trading (real money)

---

## 📦 **Installation**

### **Prerequisites**

1. **Python 3.9 or higher**
   - Download from: https://python.org
   - Make sure to check "Add Python to PATH" during installation

2. **MetaMask Wallet**
   - Install from: https://metamask.io
   - Create wallet and save seed phrase securely

3. **Polygon Network Setup**
   - Add Polygon network to MetaMask:
     - Network Name: Polygon Mainnet
     - RPC URL: https://polygon-rpc.com
     - Chain ID: 137
     - Currency Symbol: MATIC
     - Block Explorer: https://polygonscan.com

4. **Funds**
   - Get MATIC on Polygon network ($10-20 to start)
   - Bridge from Ethereum or buy directly on an exchange
   - Send to your MetaMask wallet on Polygon network

5. **Alchemy API Key** (free)
   - Sign up at: https://alchemy.com
   - Create a new app for Polygon Mainnet
   - Copy your API key

### **Setup Steps**

#### **Windows**

1. **Download/Clone the project**
   ```bash
   git clone <your-repo-url>
   cd memecoin-sniper
   ```

2. **Run setup script**
   ```bash
   setup.bat
   ```

3. **Configure bot**
   - Open `config.json` in a text editor
   - Add your private key
   - Add your wallet address
   - Add your Alchemy API key
   - Set mode to `"paper"` for testing

4. **Get your private key from MetaMask**
   - Open MetaMask
   - Click three dots → Account Details → Export Private Key
   - Enter password
   - Copy private key (64 characters)
   - ⚠️ **NEVER share this with anyone!**

#### **Mac/Linux**

1. **Download/Clone the project**
   ```bash
   git clone <your-repo-url>
   cd memecoin-sniper
   ```

2. **Setup manually**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Configure** (same as Windows step 3-4 above)

---

## ⚙️ **Configuration Guide**

Edit `config.json`:

### **Wallet Settings**
```json
"wallet": {
  "private_key": "YOUR_64_CHARACTER_PRIVATE_KEY",
  "address": "0xYOUR_WALLET_ADDRESS"
}
```

### **Network Settings**
```json
"network": {
  "rpc_url": "https://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY",
  "chain_id": 137,
  "gas_price_gwei": 50,
  "gas_limit": 500000
}
```

### **Trading Settings**
```json
"trading": {
  "mode": "paper",  // "paper" or "live"
  "min_liquidity_usd": 1000,
  "max_liquidity_usd": 100000,
  "position_size_percent": 20,  // 20% of wallet per trade
  "max_slippage_percent": 15,
  "min_score_threshold": 70  // Minimum score to trade
}
```

### **Profit Strategy**
```json
"profit_strategy": {
  "take_profit_3x": 30,   // Sell 30% at 3x
  "take_profit_5x": 40,   // Sell 40% at 5x
  "take_profit_10x": 30,  // Sell 30% at 10x
  "trailing_stop_percent": 20,  // Stop if drops 20% from peak
  "max_hold_time_minutes": 60   // Auto-sell after 60 min
}
```

### **Safety Settings**
```json
"safety": {
  "check_honeypot": true,
  "check_mint_function": true,
  "check_blacklist_function": true,
  "min_holders": 10,
  "max_buy_tax": 10,
  "max_sell_tax": 10
}
```

---

## 🚀 **Running the Bot**

### **Paper Trading Mode (Recommended First)**

```bash
# Activate virtual environment
venv\Scripts\activate  # Windows
source venv/bin/activate  # Mac/Linux

# Run bot
python bot.py
```

The bot will:
1. Connect to Polygon RPC
2. Start scanning for new tokens
3. Analyze and score tokens
4. Simulate trades (paper mode)
5. Log all activity

### **Live Trading Mode** (After testing)

1. **Edit config.json**
   ```json
   "trading": {
     "mode": "live"
   }
   ```

2. **Run bot**
   ```bash
   python bot.py
   ```

3. **Monitor logs**
   - Check console output
   - Review logs in `logs/` folder
   - Watch for trade notifications

---

## 📊 **Understanding the Bot**

### **Scanning Process**

Every 15 seconds:
1. Scan recent blocks for new token pairs
2. Filter by age (60-600 seconds old)
3. Extract token details

### **Analysis Process**

For each new token:
1. **Safety Check**
   - Check for honeypot indicators
   - Scan contract for dangerous functions
   - Verify liquidity levels
   
2. **Scoring**
   - Liquidity: Higher score for $2K-$20K range
   - Age: Higher score for 2-5 minute old tokens
   - Volume: Higher score for active trading
   - Momentum: Higher score for rising prices
   - Safety: Deducts points for risks

3. **Decision**
   - If score >= 70 and safety passed → BUY
   - If score < 70 or safety failed → SKIP

### **Position Management**

After buying:
1. Monitor price every scan
2. Check profit targets:
   - 3x: Sell 30%
   - 5x: Sell 40%
   - 10x: Sell 30%
3. Apply trailing stop (20% from peak)
4. Auto-close after 60 minutes

### **Example Trade Flow**

```
Token found: $MOON
├─ Age: 180s ✓
├─ Liquidity: $5,000 ✓
├─ Safety check: PASSED ✓
├─ Score: 75/100 ✓
└─ Action: BUY 0.5 MATIC

Position opened
├─ Entry price: $0.0001
├─ Tokens: 5000
└─ Watching for targets...

Price hits $0.0003 (3x)
└─ Sell 30% → 1500 tokens

Price hits $0.00015 (dropped 50% from peak)
└─ Trailing stop triggered → Sell remaining 70%

Position closed
├─ P&L: +120%
└─ Profit: 0.6 MATIC
```

---

## 🧪 **Testing Guide**

### **Phase 1: Paper Trading (1-2 days)**

1. **Set mode to "paper"**
2. **Run bot and observe:**
   - Are new tokens being detected?
   - Is scoring working correctly?
   - Are simulated trades reasonable?
3. **Adjust config if needed:**
   - Lower min_score if too few trades
   - Adjust liquidity ranges
   - Modify profit targets

### **Phase 2: Small Live Test ($10)**

1. **Set mode to "live"**
2. **Set position_size_percent to 20%**
3. **Fund wallet with $10-20 MATIC**
4. **Run for 6-24 hours**
5. **Monitor results:**
   - Are real trades executing?
   - Are fees reasonable?
   - Is P&L tracking correctly?

### **Phase 3: Full Deployment**

1. **If Phase 2 successful, increase capital**
2. **Continue monitoring and adjusting**
3. **Keep detailed records**

---

## 📈 **Expected Results**

### **Realistic Expectations**

**Win Rate**: 20-40%
- Most memecoins fail
- You'll have more losing trades than winners
- Big winners offset many small losses

**Profit Targets**:
- Small wins: 50-100% (common)
- Medium wins: 3-5x (occasional)
- Big wins: 10x+ (rare but game-changing)

**With $20 starting capital**:
- Best case month: +200% ($60 total)
- Average case month: +50% ($30 total)
- Worst case month: -50% ($10 total)

### **Key Success Factors**

1. **Early detection** (first 2-5 minutes)
2. **Strict safety filtering**
3. **Taking profits at targets**
4. **Cutting losses quickly**
5. **Position sizing discipline**

---

## 🛡️ **Safety & Security**

### **Protecting Your Private Key**

- ✅ Never commit `config.json` to Git
- ✅ Use dedicated wallet for bot
- ✅ Keep only necessary funds in bot wallet
- ✅ Store private key securely offline
- ❌ Never share private key
- ❌ Never paste in Discord/Telegram
- ❌ Don't screenshot private key

### **Security Best Practices**

1. **Use separate bot wallet**
   - Don't use main MetaMask wallet
   - Create new wallet just for bot

2. **Limit funds**
   - Only keep $20-50 in bot wallet
   - Withdraw profits regularly

3. **Monitor activity**
   - Check transactions on Polygonscan
   - Review logs daily
   - Watch for unusual behavior

4. **Keep software updated**
   - Update dependencies regularly
   - Check for bot updates

---

## 🔧 **Troubleshooting**

### **Bot won't start**

- Check Python version: `python --version` (need 3.9+)
- Check config.json is valid JSON
- Verify private key is correct format
- Check RPC connection

### **No tokens detected**

- Polygon might have low new token activity
- Adjust `lookback_blocks` in config
- Lower `min_age_seconds`
- Check RPC is responding

### **All tokens fail safety check**

- This is normal! Most tokens are scams
- Lower `min_score_threshold` temporarily for testing
- Check `check_honeypot` settings

### **Trades not executing (live mode)**

- Check wallet has MATIC balance
- Verify gas settings (might be too low)
- Check slippage tolerance
- Review error logs

### **High gas fees**

- Adjust `gas_price_gwei` in config
- Trade during low-activity times
- Use default Polygon RPC (cheaper)

---

## 📝 **Logs & Monitoring**

### **Console Output**

Real-time feed shows:
- New tokens detected
- Safety check results
- Scoring breakdown
- Trade executions
- Position updates
- P&L tracking

### **Log Files**

Located in `logs/` folder:
- `bot_YYYYMMDD_HHMMSS.log` - Full detailed logs
- Review for debugging
- Track trade history
- Analyze performance

### **What to Watch**

✅ **Good signs:**
- Tokens being detected regularly
- Safety checks working
- Scores varying (not all 0 or 100)
- Reasonable trade frequency

⚠️ **Warning signs:**
- No tokens detected for hours
- All trades failing
- Extremely high gas costs
- Connection errors

---

## 💡 **Optimization Tips**

### **Improve Detection**

1. **Adjust age window**
   - Sweet spot: 120-300 seconds
   - Too early: More scams
   - Too late: Missed pump

2. **Optimize liquidity range**
   - $2K-$20K: Good for small cap
   - $5K-$50K: Safer but less upside

3. **Score threshold**
   - 70: Balanced
   - 80: Very selective
   - 60: More aggressive

### **Better Profits**

1. **Take partial profits**
   - Don't wait for 10x every time
   - Secure gains at 3x and 5x

2. **Tighten trailing stop**
   - 20%: Balanced
   - 15%: Lock profits faster
   - 30%: Ride trends longer

3. **Monitor and adjust**
   - Review closed trades weekly
   - Adjust strategy based on results
   - Learn from losses

---

## 📚 **Advanced Features**

### **DexScreener Integration** (Optional)

Add trending score from DexScreener:
- Uncomment DexScreener API calls in `token_scorer.py`
- Weights trending tokens higher
- Catches viral memecoins early

### **Social Signals** (Future)

Planned features:
- Twitter mention tracking
- Telegram group detection
- Discord activity monitoring
- Reddit sentiment

### **Multi-DEX Support** (Future)

Expand to:
- Uniswap V3 on Polygon
- SushiSwap
- Curve (for stablecoin pairs)

---

## ❓ **FAQ**

**Q: How much can I make?**
A: Highly variable. Some trades 10x, most fail. With discipline, targeting 50-200% monthly is possible but not guaranteed.

**Q: Is this illegal?**
A: No, but check your local regulations. You're responsible for taxes on profits.

**Q: Will I get rekt?**
A: Possibly! Only use money you can afford to lose. Memecoins are extremely risky.

**Q: How often does it trade?**
A: Depends on market activity. Could be 0-10 trades per day.

**Q: Can I run 24/7?**
A: Yes, on a VPS or home PC. Just monitor periodically.

**Q: What if I miss a 100x?**
A: It happens. The bot prioritizes safety over catching every pump.

---

## 🙏 **Disclaimer**

This software is provided "as is" for educational purposes. The authors are not responsible for any financial losses. Cryptocurrency trading is high risk. Never invest more than you can afford to lose. This is not financial advice. Do your own research.

---

## 📞 **Support**

Having issues? Check:
1. This README
2. Log files in `logs/`
3. Config.json settings
4. Your wallet balance and RPC connection

---

**Good luck and trade safely!** 🚀
