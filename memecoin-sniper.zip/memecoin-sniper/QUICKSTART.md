# ⚡ Quick Start Guide - 5 Minutes to First Trade

Get your memecoin sniper bot running in 5 minutes!

---

## 📋 **Prerequisites Checklist**

Before starting, have these ready:
- [ ] Python 3.9+ installed
- [ ] MetaMask wallet with Polygon network added
- [ ] 10-20 MATIC on Polygon in your wallet
- [ ] Alchemy account (free) with Polygon API key
- [ ] Your MetaMask private key (export from MetaMask)

---

## 🚀 **Installation (2 minutes)**

### **Step 1: Download & Setup**

```bash
# Clone or download project
cd memecoin-sniper

# Run setup (Windows)
setup.bat

# Or manually (Mac/Linux)
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### **Step 2: Configure**

Open `config.json` and add:

```json
{
  "wallet": {
    "private_key": "YOUR_PRIVATE_KEY_HERE",  // From MetaMask
    "address": "0xYOUR_WALLET_ADDRESS"
  },
  "network": {
    "rpc_url": "https://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY",
    ...
  },
  "trading": {
    "mode": "paper",  // START WITH PAPER TRADING!
    ...
  }
}
```

### **Step 3: Run**

```bash
python bot.py
```

That's it! Bot is now running in paper trading mode.

---

## 📊 **What You'll See**

```
================================================================================
MEMECOIN SNIPER BOT - INITIALIZING
================================================================================
Wallet: 0x1234...abcd
Balance: 15.2500 MATIC

Mode: PAPER
📝 Paper trading - no real transactions

Settings:
   Position Size: 20% per trade
   Min Score: 70/100
   Scan Interval: 15s
   Min Liquidity: $1,000
   Max Slippage: 15%

✓ Bot initialized successfully!

================================================================================
BOT STARTED - SCANNING FOR OPPORTUNITIES
================================================================================

────────────────────────────────────────────────────────────
Scan #1 - 14:23:45
────────────────────────────────────────────────────────────
Found 2 new token(s)

🔍 NEW TOKEN DETECTED
   Address: 0x...
   Symbol: MOON
   Liquidity: $5,234.56
   Age: 180s

🔍 Analyzing: MOON
📊 Score: 75/100
   - Liquidity: 20/20
   - Age: 15/15
   - Volume: 10/20
   - Momentum: 8/15
   - Safety: 22/30

✅ HIGH SCORE TOKEN FOUND: MOON

💰 BUY SETUP: MOON
Spending: 3.0500 MATIC
Expecting: ~15234.56 tokens

💰 EXECUTING BUY
   Token: MOON
   Amount: 3.0500 MATIC
   Expected: 15234.56 tokens
   MODE: PAPER TRADING (not executed)

✓ Position opened in MOON
```

---

## 🎯 **Testing in Paper Mode (First 24 Hours)**

### **What to Check**

1. **Are tokens being found?**
   - Should see new tokens every few scans
   - If not, Polygon might be slow (normal)

2. **Is scoring reasonable?**
   - Scores should vary (50-90 range)
   - Most tokens should fail (60-80% rejection rate)

3. **Are simulated trades logical?**
   - Position sizes match config (20% of balance)
   - Expected tokens make sense
   - No errors in console

### **Adjust If Needed**

**Too few trades:**
```json
"min_score_threshold": 60  // Lower from 70
```

**Too many unsafe tokens:**
```json
"min_liquidity_usd": 2000  // Raise from 1000
```

**Want faster scanning:**
```json
"interval_seconds": 10  // Lower from 15
```

---

## 💰 **Going Live (After 24hr Paper Test)**

### **Step 1: Verify Paper Results**

Check you've seen:
- ✅ Multiple tokens detected
- ✅ Safety checks working
- ✅ Simulated trades executing
- ✅ No major errors

### **Step 2: Switch to Live Mode**

Edit `config.json`:
```json
"trading": {
  "mode": "live",  // Changed from "paper"
  "position_size_percent": 20  // Start small!
}
```

### **Step 3: Fund Wallet**

- Send 10-20 MATIC to your bot wallet
- Verify balance in bot output
- Keep extra funds elsewhere (not in bot wallet)

### **Step 4: Start Live**

```bash
python bot.py
```

You'll see:
```
Mode: LIVE
⚠️  LIVE TRADING - real money at risk!
```

### **Step 5: Monitor**

- Watch first few trades closely
- Check transactions on Polygonscan
- Verify profits/losses match expectations

---

## 📈 **First Week Strategy**

### **Day 1-2: Paper Trading**
- Let it run 24 hours
- Check logs twice daily
- Adjust settings if needed

### **Day 3-4: Small Live Test**
- $10-20 starting capital
- Position size: 20%
- Let 2-3 trades complete
- Evaluate results

### **Day 5-7: Optimize**
- If profitable → continue
- If breaking even → adjust thresholds
- If losing → back to paper mode

---

## 🎓 **Quick Tips**

### **Do's** ✅
- Start with paper trading
- Use small capital first ($10-20)
- Take profits at targets
- Monitor logs daily
- Keep detailed records

### **Don'ts** ❌
- Don't skip paper trading
- Don't invest life savings
- Don't ignore stop losses
- Don't chase pumps manually
- Don't share private key

---

## 🚨 **Emergency Stop**

If something goes wrong:

1. **Press Ctrl+C** to stop bot
2. **Check open positions** in logs
3. **Manually close** on QuickSwap if needed
4. **Review what happened**

---

## 📊 **Expected First Week**

**Paper Trading:**
- Trades: 5-20 simulated
- Profit: N/A (simulated)
- Learn: How bot behaves

**Live Trading ($20 capital):**
- Trades: 2-5 real
- Win rate: 20-40%
- Profit range: -$5 to +$15
- Learn: Real market dynamics

---

## 🎯 **Success Metrics**

After first week, evaluate:

✅ **Good signs:**
- Bot runs without crashing
- Detects tokens regularly
- Safety checks mostly reject scams
- Occasional profitable trades

⚠️ **Warning signs:**
- Constant errors/crashes
- No tokens detected
- All trades losing money
- Safety checks failing

---

## 🔄 **Next Steps**

After successful first week:

1. **Optimize Settings**
   - Adjust score thresholds
   - Fine-tune profit targets
   - Modify safety filters

2. **Scale Up** (Optional)
   - Increase to $50-100 capital
   - Keep position size at 20-30%
   - Maintain strict risk management

3. **Monitor & Improve**
   - Weekly performance review
   - Adjust based on results
   - Stay disciplined

---

## 📞 **Need Help?**

**Common Issues:**

1. **"Cannot connect to RPC"**
   - Check Alchemy API key
   - Verify internet connection
   - Try different RPC URL

2. **"No tokens found"**
   - Normal! New tokens are sporadic
   - Wait 1-2 hours
   - Try lowering min_age_seconds

3. **"All trades failing"**
   - Check wallet has MATIC
   - Verify gas settings
   - Review error messages

4. **"Bot crashes"**
   - Check Python version (3.9+)
   - Reinstall dependencies
   - Review crash logs

---

## 🎉 **You're Ready!**

You now have:
- ✅ Bot installed and configured
- ✅ Understanding of paper vs live trading
- ✅ Testing strategy
- ✅ Risk management plan

**Start with paper trading, be patient, and trade safe!** 🚀

---

*Remember: This is high-risk trading. Only use money you can afford to lose completely.*
