# 📈 Trading Strategy Explained

Understanding how the memecoin sniper bot makes trading decisions.

---

## 🎯 **Core Strategy: Early Detection + Safety First**

The bot combines three key elements:
1. **Speed**: Detect tokens in first 2-10 minutes
2. **Safety**: Filter out scams and honeypots
3. **Exits**: Take profits aggressively and cut losses fast

---

## 🔍 **Detection Phase**

### **What We're Looking For**

**Newly launched tokens that:**
- Just got liquidity (2-10 minutes ago)
- Have reasonable liquidity ($1K-$100K)
- Are paired with WMATIC or USDC
- Show early trading activity

### **Why Early Matters**

```
Token Launch Timeline:
0-2 min:   Developer & bots buy in (too risky)
2-5 min:   Early traders enter (SWEET SPOT)
5-15 min:  Viral spread begins (good)
15-60 min: Peak pump happens (risky)
1+ hour:   Usually dumping (too late)
```

**Our target**: 2-5 minute window

### **Liquidity Sweet Spot**

- **< $1,000**: Too risky, easy to manipulate
- **$1K-$5K**: Small cap gems, high risk/reward
- **$5K-$20K**: **Optimal zone** - enough liquidity, still early
- **$20K-$100K**: Safer but less upside
- **> $100K**: Probably not a memecoin anymore

---

## 🛡️ **Safety Analysis**

### **Multi-Layer Safety Checks**

#### **1. Honeypot Detection**
```
Test: Can we buy AND sell?
Method: Simulate balanceOf call
Red flags:
  - Function reverts
  - Returns unexpected values
  - Contract behaves oddly
```

#### **2. Dangerous Function Check**
```
Scanning for:
  ❌ mint() - Can create unlimited tokens
  ❌ blacklist() - Can block sells
  ❌ pause() - Can stop trading
  ❌ setMaxTx() - Can limit sells
```

#### **3. Ownership Check**
```
Safe:   Owner = 0x000...000 (renounced)
Risky:  Owner = active address
```

#### **4. Liquidity Verification**
```
Minimum: $1,000
Maximum: $100,000
Verify: Actually exists in pool
```

### **Safety Scoring**

```
Base score: 100 points

Deductions:
- Mint function found:      -40 points
- Blacklist function:       -40 points
- Pause function:           -20 points
- Liquidity too low:        -30 points
- Failed honeypot test:     -50 points
- Cannot verify code:       -20 points

Passing score: >= 50 points
```

---

## 📊 **Token Scoring System**

### **5 Scoring Categories**

#### **1. Liquidity Score (0-20 points)**

```
Optimal range: $2K-$20K

Scoring:
< $1K:        0 points  (too risky)
$1K-$2K:      5 points  (risky)
$2K-$20K:    20 points  (PERFECT)
$20K-$50K:   15 points  (good)
$50K-$100K:  10 points  (okay)
> $100K:      5 points  (established)
```

**Why**: $2K-$20K hits sweet spot between:
- Enough liquidity for entry/exit
- Still early enough for big gains
- Not yet discovered by masses

#### **2. Age Score (0-15 points)**

```
Token age scoring:
< 60s:        5 points  (too fresh)
60-120s:     10 points  (early)
120-300s:    15 points  (PERFECT)
300-600s:    10 points  (good)
> 600s:       5 points  (getting late)
```

**Why**: 2-5 minutes is the goldilocks zone:
- Scam tokens often rug within 2 min
- Viral memecoins pump minutes 3-10
- After 10 min, harder to get good entry

#### **3. Volume Score (0-20 points)**

```
5-minute volume:
> $10K:      20 points  (very active)
$5K-$10K:    15 points  (active)
$1K-$5K:     10 points  (moderate)
$100-$1K:     5 points  (slow)
< $100:       0 points  (dead)
```

**Why**: Volume = interest
- High volume = viral potential
- Low volume = might not pump
- Sudden spikes = possible manipulation

#### **4. Price Momentum (0-15 points)**

```
5-minute price change:
> +50%:      15 points  (mooning)
+20% to +50%:12 points  (strong)
0% to +20%:   8 points  (rising)
-10% to 0%:   5 points  (stable)
< -10%:       0 points  (dumping)
```

**Why**: Momentum matters
- Rising price = buying pressure
- Flat price = waiting for catalyst
- Falling price = early holders dumping

#### **5. Safety Score (0-30 points)**

```
Safety check result scaled to 30 points:
100% safe: 30 points
75% safe:  22 points
50% safe:  15 points
< 50%:      0 points (auto-reject)
```

**Why**: Safety is most important
- Can't profit if you get rugged
- Even 10x gains don't matter if you can't sell

### **Total Score Calculation**

```
Total = Liquidity + Age + Volume + Momentum + Safety
Maximum possible: 100 points
Minimum to trade: 70 points (configurable)
```

### **Example Scoring**

**Token: $MOON**
```
Liquidity: $8,500          → 20 points ✅
Age: 240 seconds           → 15 points ✅
Volume (5min): $3,200      → 10 points ⚠️
Momentum: +35% in 5min     → 12 points ✅
Safety: Passed all checks  → 25 points ✅
─────────────────────────────────────
TOTAL SCORE: 82/100        → TRADE ✅
```

**Token: $SCAM**
```
Liquidity: $15,000         → 20 points ✅
Age: 45 seconds            →  5 points ⚠️
Volume: $200               →  5 points ⚠️
Momentum: -5%              →  5 points ⚠️
Safety: Mint function!     →  5 points ❌
─────────────────────────────────────
TOTAL SCORE: 40/100        → REJECT ❌
```

---

## 💰 **Entry Strategy**

### **Position Sizing**

```
Default: 20% of wallet balance per trade

Example with $50 wallet:
Trade 1: $10 (20% of $50)
Trade 2: $8  (20% of $40 remaining)
Trade 3: $6.40 (20% of $32 remaining)

This allows 4-5 positions maximum
```

**Why 20%?**
- Limits risk per trade
- Allows diversification
- Preserves capital for next opportunities

### **Slippage Protection**

```
Max slippage: 15% (default)

If expected: 10,000 tokens
Min accepted: 8,500 tokens

Transaction reverts if slippage > 15%
```

**Why 15%?**
- Memecoins are volatile
- 10% often not enough
- 15% balances execution vs price impact

### **Gas Settings**

```
Gas price: 50 gwei (default)
Gas limit: 500,000

Polygon is cheap:
- Average cost: $0.05-0.20 per trade
- During congestion: $0.50-1.00
```

---

## 📈 **Exit Strategy**

### **Profit Targets (Multi-Exit)**

Instead of selling all at once, we scale out:

```
Entry price: $0.0001

3x Target ($0.0003):
  → Sell 30% of position
  → Lock in initial investment
  → Let 70% ride

5x Target ($0.0005):
  → Sell 40% of remaining
  → Secure good profits
  → Let 42% ride

10x Target ($0.001):
  → Sell 30% of remaining
  → Book massive gains
  → Let 29% ride for moon

Result: Secured profits + still exposed to upside
```

**Why multi-exit?**
- Most tokens don't hit 10x
- Secure profits on the way up
- Avoid "sold too early" regret
- Avoid "held too long" regret

### **Trailing Stop Loss**

```
Tracks highest price reached

Example:
Entry: $0.0001
Peak: $0.0008 (8x)
Current: $0.00064 (6.4x)

Drawdown from peak:
($0.0008 - $0.00064) / $0.0008 = 20%

→ Trailing stop triggers
→ Sell entire remaining position
```

**Why 20% trailing stop?**
- Locks in profits after pumps
- Protects against sudden dumps
- Allows room for volatility

### **Max Hold Time**

```
Default: 60 minutes

After 60 minutes:
  → Auto-sell entire position
  → Regardless of profit/loss
  → Move on to next opportunity
```

**Why 60 minutes?**
- Memecoin pumps are fast
- Holding longer = higher risk
- Capital better deployed elsewhere

### **Example Trade Lifecycle**

```
00:00 - Entry at $0.0001 (5000 tokens, 0.5 MATIC)

05:15 - Price $0.0003 (3x)
        → Sell 1500 tokens for 0.45 MATIC
        → Secured initial investment
        → 3500 tokens remaining

12:30 - Price $0.0005 (5x) 
        → Sell 1400 tokens for 0.70 MATIC
        → Locked in 1.15 MATIC total (2.3x)
        → 2100 tokens remaining

15:45 - Peak $0.0007 (7x)
        → No action (no 10x yet)
        → Trailing stop active

18:20 - Price drops to $0.00056 (20% from peak)
        → Trailing stop triggers
        → Sell 2100 tokens for 1.176 MATIC
        
Final: 
  → Total out: 2.326 MATIC
  → Invested: 0.5 MATIC
  → Profit: 1.826 MATIC (+365%)
  → Hold time: 18 minutes
```

---

## ⚠️ **Risk Management**

### **Position Limits**

```
Max per trade: 30% of wallet
Recommended: 20% of wallet
Conservative: 10% of wallet

Prevents blow-up from single bad trade
```

### **Safety Filters**

```
ALWAYS skip if:
  ❌ Mint function found
  ❌ Blacklist function found
  ❌ Failed honeypot test
  ❌ Liquidity < $1,000
  ❌ Safety score < 50

Better to miss gain than get rugged
```

### **Stop Loss Discipline**

```
Never disable:
  - Trailing stop
  - Max hold time
  - Slippage protection

These are your safety net
```

---

## 📊 **Profit Math**

### **Expected Outcomes**

```
Win Rate: ~30%

100 trades:
- 70 losses: -$7 each = -$490
- 20 small wins: +$15 each = +$300
- 8 medium wins: +$50 each = +$400
- 2 big wins: +$200 each = +$400

Total: +$610 profit (+61% with $1,000 starting)
```

**Key insight**: Big wins offset many small losses

### **Realistic Monthly Returns**

```
Starting: $20

Conservative (10% monthly):
Month 1: $22
Month 6: $32
Month 12: $63

Moderate (50% monthly):
Month 1: $30
Month 6: $152
Month 12: $2,462

Aggressive (100% monthly):
Month 1: $40
Month 6: $1,280
Month 12: $81,920

Reality: Somewhere between conservative and moderate
```

---

## 🎓 **Strategy Improvements**

### **For Better Detection**

1. **Monitor trending on DexScreener**
2. **Track Twitter mentions**
3. **Watch Telegram group growth**
4. **Check contract deployment time**

### **For Better Entries**

1. **Wait for first pullback**
2. **Check for locked liquidity**
3. **Verify team isn't suspicious**
4. **Look for organic growth signs**

### **For Better Exits**

1. **Adjust targets based on market**
2. **Consider partial exit at 2x**
3. **Tighten trailing stop after big gains**
4. **Use time-based exits during low volatility**

---

## 🚀 **The Edge**

**Why this strategy works:**

1. **Speed**: Automated detection beats manual
2. **Safety**: Filters remove 80%+ of scams
3. **Discipline**: No emotions, just logic
4. **Scaling**: Takes profits systematically
5. **Risk**: Limits losses per trade

**Where it struggles:**

1. Tokens that pump before liquidity
2. Sophisticated rug mechanisms
3. Low activity periods (few opportunities)
4. Extreme market volatility (slippage)

---

## 💡 **Final Strategy Tips**

✅ **Do:**
- Trust the scoring system
- Take profits at targets
- Use stop losses always
- Review and adapt weekly

❌ **Don't:**
- Override safety checks
- Hold past max time
- Chase pumps manually
- Revenge trade after losses

---

*Remember: This is probabilistic, not guaranteed. Some trades will fail. The goal is net positive over many trades.*
