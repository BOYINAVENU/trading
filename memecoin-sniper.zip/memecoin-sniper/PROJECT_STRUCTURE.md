# 📁 Project Structure & Code Explanation

Understanding how the memecoin sniper bot is organized.

---

## 🗂️ **File Structure**

```
memecoin-sniper/
├── 📄 bot.py                    # Main orchestrator
├── 📄 config_loader.py          # Configuration management
├── 📄 logger.py                 # Logging system
├── 📄 token_scanner.py          # Token detection
├── 📄 safety_checker.py         # Security analysis
├── 📄 token_scorer.py           # Scoring engine
├── 📄 trading_engine.py         # Buy/sell execution
├── 📄 position_manager.py       # Position tracking
│
├── 📄 config.json               # Your settings (SENSITIVE!)
├── 📄 requirements.txt          # Python dependencies
├── 📄 setup.bat                 # Windows setup script
├── 📄 .gitignore                # Git exclusions
│
├── 📖 README.md                 # Main documentation
├── 📖 QUICKSTART.md             # Quick start guide
├── 📖 STRATEGY.md               # Strategy explanation
├── 📖 PROJECT_STRUCTURE.md      # This file
│
└── 📁 logs/                     # Log files (auto-created)
    └── bot_YYYYMMDD_HHMMSS.log
```

---

## 🔧 **Core Modules**

### **1. bot.py** - Main Orchestrator

**Purpose**: Coordinates all components and runs main loop

**Key Functions**:
```python
class MemecoinSniperBot:
    async def initialize()      # Setup and verify
    async def run()              # Main scanning loop
    async def analyze_and_trade() # Token analysis pipeline
    async def monitor_positions() # Track open trades
    async def shutdown()         # Graceful exit
```

**Flow**:
1. Load config
2. Connect to blockchain
3. Start main loop
4. Scan → Analyze → Trade → Monitor → Repeat

---

### **2. config_loader.py** - Configuration

**Purpose**: Load and validate settings from config.json

**Key Features**:
- Loads JSON configuration
- Validates critical settings
- Provides property accessors
- Checks for common mistakes

**Usage**:
```python
config = Config()
config.wallet_private_key
config.is_paper_trading()
config.min_score_threshold
```

---

### **3. logger.py** - Logging System

**Purpose**: Centralized logging with colors and file output

**Log Types**:
- `info()` - General information (cyan)
- `success()` - Success messages (green)
- `warning()` - Warnings (yellow)
- `error()` - Errors (red)
- `trade()` - Trade events (magenta)
- `opportunity()` - High-score tokens (green)

**Features**:
- Console output with colors
- File logging for history
- Trade performance tracking
- Daily summaries

---

### **4. token_scanner.py** - Token Detection

**Purpose**: Find newly launched tokens on QuickSwap

**How It Works**:
```
1. Query recent blocks
2. Filter PairCreated events from factory
3. Identify new tokens (not WMATIC/USDC)
4. Extract token details
5. Calculate liquidity
6. Return token data
```

**Key Functions**:
```python
async def scan_for_new_tokens()
    → Returns list of new tokens

def _identify_new_token(token0, token1)
    → Determines which is the memecoin

async def _get_token_details(address)
    → Gets name, symbol, liquidity, etc.
```

---

### **5. safety_checker.py** - Security Analysis

**Purpose**: Identify scams, honeypots, and dangerous contracts

**Checks Performed**:
1. **Contract Code Scan**
   - Looks for dangerous function signatures
   - Checks bytecode for mint/blacklist/pause

2. **Honeypot Test**
   - Simulates buy/sell
   - Verifies contract behaves normally

3. **Liquidity Verification**
   - Checks within acceptable range
   - Ensures real liquidity exists

4. **Ownership Check**
   - Verifies if renounced
   - Identifies active owner

**Output**:
```python
{
    'safe': True/False,
    'score': 0-100,
    'issues': ['list', 'of', 'problems']
}
```

---

### **6. token_scorer.py** - Scoring Engine

**Purpose**: Calculate token potential score (0-100)

**Scoring Categories**:
1. Liquidity (0-20 pts)
2. Age (0-15 pts)
3. Volume (0-20 pts)
4. Price Momentum (0-15 pts)
5. Safety (0-30 pts)

**Process**:
```python
async def score_token(token_data, safety_result)
    → Calculate each category
    → Sum total score
    → Determine if tradeable
    → Return detailed breakdown
```

**Example Output**:
```python
{
    'total_score': 75,
    'breakdown': {
        'liquidity': 20,
        'age': 15,
        'volume': 10,
        'price_momentum': 8,
        'safety': 22
    },
    'reasons': ['Liquidity: 20/20', ...],
    'tradeable': True
}
```

---

### **7. trading_engine.py** - Trade Execution

**Purpose**: Execute buy/sell trades on QuickSwap

**Key Functions**:

```python
async def buy_token(token_info, balance)
    → Calculate position size
    → Get quote from router
    → Execute buy (real or simulated)
    → Return trade result

async def sell_token(position_info)
    → Calculate sell amount
    → Get quote from router
    → Execute sell (real or simulated)
    → Return trade result
```

**Paper vs Live Trading**:
- Paper: Simulates trades, logs as if real
- Live: Executes actual blockchain transactions

**Safety Features**:
- Slippage protection
- Gas price limits
- Quote verification before execution

---

### **8. position_manager.py** - Position Tracking

**Purpose**: Track open positions and manage exits

**Key Functions**:

```python
def open_position(token_data, buy_result)
    → Record new position
    → Set entry price
    → Initialize targets

def update_position(token_address, current_price)
    → Check profit targets (3x, 5x, 10x)
    → Monitor trailing stop
    → Check max hold time
    → Return exit signals

def close_position(token_address, exit_price, reason)
    → Calculate P&L
    → Log results
    → Archive position
```

**Position Data Structure**:
```python
{
    'token_address': '0x...',
    'token_symbol': 'MOON',
    'entry_price': 0.0001,
    'token_amount': 5000,
    'amount_matic': 0.5,
    'entry_time': datetime,
    'highest_price': 0.0001,
    'targets': {
        '3x': {'hit': False, 'sold_percent': 0},
        '5x': {'hit': False, 'sold_percent': 0},
        '10x': {'hit': False, 'sold_percent': 0}
    }
}
```

---

## 🔄 **Data Flow**

### **Main Loop Flow**

```
┌─────────────────────────────────────────┐
│  Bot Starts                             │
│  - Load config                          │
│  - Connect to blockchain                │
│  - Initialize components                │
└─────────────────┬───────────────────────┘
                  │
                  ▼
         ┌────────────────┐
         │  Main Loop     │ (every 15 seconds)
         └────────┬───────┘
                  │
                  ▼
    ┌─────────────────────────────┐
    │  Token Scanner              │
    │  - Query recent blocks      │
    │  - Find PairCreated events  │
    │  - Extract new tokens       │
    └────────┬────────────────────┘
             │
             ▼
    ┌─────────────────────────────┐
    │  Safety Checker             │
    │  - Check contract code      │
    │  - Test for honeypot        │
    │  - Verify liquidity         │
    └────────┬────────────────────┘
             │
             ▼
    ┌─────────────────────────────┐
    │  Token Scorer               │
    │  - Score liquidity          │
    │  - Score age                │
    │  - Score volume             │
    │  - Score momentum           │
    │  - Calculate total          │
    └────────┬────────────────────┘
             │
             ▼
        Score >= 70?
             │
      ┌──────┴──────┐
      │ No          │ Yes
      ▼             ▼
    Skip      ┌─────────────────────┐
    Token     │  Trading Engine     │
              │  - Calculate size   │
              │  - Get quote        │
              │  - Execute buy      │
              └────────┬────────────┘
                       │
                       ▼
              ┌─────────────────────┐
              │  Position Manager   │
              │  - Record position  │
              │  - Monitor price    │
              │  - Check targets    │
              │  - Execute exits    │
              └─────────────────────┘
```

### **Trade Execution Flow**

```
Token Detected
    │
    ▼
Safety Check → Pass? → Yes → Score Token
    │                            │
    No                           ▼
    │                      Score >= 70?
    │                            │
    │                           Yes
    │                            │
    │                            ▼
    │                    Get Wallet Balance
    │                            │
    │                            ▼
    │                    Calculate Position Size
    │                            │
    │                            ▼
    │                    Get Router Quote
    │                            │
    │                            ▼
    │                    Paper or Live?
    │                       │        │
    │                    Paper      Live
    │                       │        │
    │                       ▼        ▼
    │                    Simulate  Execute
    │                       │        │
    │                       └────┬───┘
    │                            │
    │                            ▼
    │                    Record Position
    │                            │
    └────────────────────────────┴──→ Next Token
```

---

## 🔌 **External Dependencies**

### **Web3 Integration**

```python
from web3 import Web3

# Connect to Polygon
w3 = Web3(Web3.HTTPProvider(rpc_url))

# Create contract instance
contract = w3.eth.contract(address, abi)

# Call functions
result = contract.functions.someFunction().call()

# Send transactions
tx = contract.functions.someFunction().build_transaction({...})
signed = account.sign_transaction(tx)
tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
```

### **QuickSwap Router**

```python
# Router address on Polygon
QUICKSWAP_ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff"

# Key functions used:
- getAmountsOut(amountIn, path) # Get quote
- swapExactETHForTokens(...) # Buy tokens
- swapExactTokensForETH(...) # Sell tokens
```

### **Factory Contract**

```python
# Factory address on Polygon
QUICKSWAP_FACTORY = "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32"

# Monitors PairCreated events:
event PairCreated(
    address indexed token0,
    address indexed token1,
    address pair,
    uint256
)
```

---

## 🧩 **Adding New Features**

### **Adding a New Safety Check**

Edit `safety_checker.py`:

```python
async def _check_new_thing(self, token_data):
    """Your new check"""
    try:
        # Implement check logic
        is_safe = check_something()
        
        if not is_safe:
            return True, "❌ Failed new check"
        return False, "✓ Passed new check"
    except:
        return None, "⚠️  Could not check"

# Add to check_token_safety():
new_result = await self._check_new_thing(token_data)
if new_result[0]:
    safety_score -= 20
    issues.append(new_result[1])
```

### **Adding a New Scoring Factor**

Edit `token_scorer.py`:

```python
def _score_new_factor(self, token_data):
    """Score based on new factor (0-10 points)"""
    value = token_data.get('new_factor', 0)
    
    if value > 100:
        return 10
    elif value > 50:
        return 5
    else:
        return 0

# Add to score_token():
scores['new_factor'] = self._score_new_factor(token_data)
# Update max points accordingly
```

### **Adding Social Signals**

Create new module `social_tracker.py`:

```python
async def check_twitter_mentions(token_symbol):
    # Use Twitter API
    pass

async def check_telegram_groups(token_address):
    # Check Telegram
    pass

# Integrate into token_scorer.py
```

---

## 🐛 **Debugging Guide**

### **Common Issues & Where to Look**

| Issue | Check File | Function |
|-------|-----------|----------|
| No tokens found | `token_scanner.py` | `scan_for_new_tokens()` |
| All fail safety | `safety_checker.py` | `check_token_safety()` |
| Low scores | `token_scorer.py` | `score_token()` |
| Trades fail | `trading_engine.py` | `execute_buy_live()` |
| Positions not tracked | `position_manager.py` | `open_position()` |
| Config errors | `config_loader.py` | `_validate_config()` |

### **Enable Debug Logging**

Edit `config.json`:
```json
"logging": {
    "level": "DEBUG"  // Was "INFO"
}
```

### **Test Individual Components**

```python
# Test scanner
scanner = TokenScanner(config, logger, w3)
tokens = await scanner.scan_for_new_tokens()
print(tokens)

# Test safety checker
checker = SafetyChecker(config, logger, w3)
result = await checker.check_token_safety(token_data)
print(result)

# Test scoring
scorer = TokenScorer(config, logger, w3, scanner)
score = await scorer.score_token(token_data, safety_result)
print(score)
```

---

## 📚 **Further Reading**

- **Web3.py Docs**: https://web3py.readthedocs.io
- **QuickSwap Docs**: https://docs.quickswap.exchange
- **Polygon Docs**: https://docs.polygon.technology
- **Solidity ABI**: https://docs.soliditylang.org/en/latest/abi-spec.html

---

*This modular structure makes it easy to understand, modify, and extend the bot's functionality.*
