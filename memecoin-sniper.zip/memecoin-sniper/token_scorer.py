"""Token scoring system - evaluates memecoin potential"""
import asyncio
import aiohttp
from datetime import datetime, timedelta

class TokenScorer:
    """Score tokens based on memecoin potential indicators"""
    
    def __init__(self, config, logger, w3, scanner):
        self.config = config
        self.logger = logger
        self.w3 = w3
        self.scanner = scanner
        self.price_history = {}
    
    async def score_token(self, token_data, safety_result):
        """Calculate comprehensive score for a token"""
        try:
            scores = {
                'liquidity': self._score_liquidity(token_data),
                'age': self._score_age(token_data),
                'volume': await self._score_volume(token_data),
                'price_momentum': await self._score_price_momentum(token_data),
                'safety': safety_result['score'] / 100 * 30,  # Safety worth 30 points
            }
            
            total_score = sum(scores.values())
            
            reasons = []
            reasons.append(f"Liquidity: {scores['liquidity']:.0f}/20")
            reasons.append(f"Age: {scores['age']:.0f}/15")
            reasons.append(f"Volume: {scores['volume']:.0f}/20")
            reasons.append(f"Momentum: {scores['price_momentum']:.0f}/15")
            reasons.append(f"Safety: {scores['safety']:.0f}/30")
            
            # Add safety issues
            for issue in safety_result.get('issues', []):
                reasons.append(issue)
            
            return {
                'total_score': int(total_score),
                'breakdown': scores,
                'reasons': reasons,
                'tradeable': total_score >= self.config.min_score_threshold and safety_result['safe']
            }
            
        except Exception as e:
            self.logger.error(f"Scoring error: {e}")
            return {'total_score': 0, 'breakdown': {}, 'reasons': [str(e)], 'tradeable': False}
    
    def _score_liquidity(self, token_data):
        """Score based on liquidity (0-20 points)"""
        liquidity = token_data.get('liquidity_usd', 0)
        
        # Optimal liquidity range: $2K - $50K
        if liquidity < 1000:
            return 0
        elif liquidity < 2000:
            return 5
        elif liquidity >= 2000 and liquidity <= 20000:
            return 20  # Sweet spot
        elif liquidity <= 50000:
            return 15
        elif liquidity <= 100000:
            return 10
        else:
            return 5  # Too much liquidity, might not be a memecoin
    
    def _score_age(self, token_data):
        """Score based on token age (0-15 points)"""
        age = token_data.get('age_seconds', 0)
        
        # Optimal: 2-5 minutes old
        if age < 60:
            return 5  # Too new, risky
        elif age >= 120 and age <= 300:
            return 15  # Perfect timing
        elif age <= 600:
            return 10  # Still good
        else:
            return 5  # Getting old
    
    async def _score_volume(self, token_data):
        """Score based on recent trading volume (0-20 points)"""
        try:
            # Get recent volume
            volume = await self.scanner.get_recent_volume(token_data['pair_address'], minutes=5)
            
            # Score based on volume
            if volume > 10000:
                return 20
            elif volume > 5000:
                return 15
            elif volume > 1000:
                return 10
            elif volume > 100:
                return 5
            else:
                return 0
        except:
            return 10  # Default middle score if we can't check
    
    async def _score_price_momentum(self, token_data):
        """Score based on price momentum (0-15 points)"""
        try:
            token_address = token_data['address']
            
            # Track price
            current_price = self._calculate_price(token_data)
            
            if token_address not in self.price_history:
                self.price_history[token_address] = []
            
            self.price_history[token_address].append({
                'price': current_price,
                'timestamp': datetime.now()
            })
            
            # Keep only last 5 minutes
            cutoff = datetime.now() - timedelta(minutes=5)
            self.price_history[token_address] = [
                p for p in self.price_history[token_address] 
                if p['timestamp'] > cutoff
            ]
            
            history = self.price_history[token_address]
            
            if len(history) < 2:
                return 5  # Not enough data
            
            # Calculate price change
            first_price = history[0]['price']
            last_price = history[-1]['price']
            
            if first_price == 0:
                return 5
            
            change_percent = ((last_price - first_price) / first_price) * 100
            
            # Score based on positive momentum
            if change_percent > 50:
                return 15  # Strong upward momentum
            elif change_percent > 20:
                return 12
            elif change_percent > 0:
                return 8
            elif change_percent > -10:
                return 5
            else:
                return 0  # Negative momentum
                
        except:
            return 5  # Default if calculation fails
    
    def _calculate_price(self, token_data):
        """Calculate token price from reserves"""
        try:
            token_reserve = token_data.get('token_reserve', 0)
            quote_reserve = token_data.get('quote_reserve', 0)
            decimals = token_data.get('decimals', 18)
            
            if token_reserve == 0:
                return 0
            
            # Price = quote_reserve / token_reserve
            price = (quote_reserve / 1e18) / (token_reserve / (10 ** decimals))
            return price
        except:
            return 0
    
    async def check_social_signals(self, token_data):
        """Check for social media buzz (placeholder)"""
        # In production, check:
        # - Twitter mentions
        # - Telegram groups
        # - Discord activity
        # - DexScreener trending
        
        return {
            'twitter_mentions': 0,
            'telegram_members': 0,
            'trending_score': 0
        }
    
    async def get_dexscreener_data(self, token_address):
        """Get data from DexScreener API"""
        try:
            url = f"https://api.dexscreener.com/latest/dex/tokens/{token_address}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        pairs = data.get('pairs', [])
                        if pairs:
                            return pairs[0]  # Return first pair
            return None
        except:
            return None
