"""Configuration loader for memecoin sniper bot"""
import json
import os
from pathlib import Path

class Config:
    """Load and manage bot configuration"""
    
    def __init__(self, config_path="config.json"):
        self.config_path = config_path
        self.config = self._load_config()
        self._validate_config()
        
    def _load_config(self):
        """Load configuration from JSON file"""
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Config file not found: {self.config_path}")
            
        with open(self.config_path, 'r') as f:
            return json.load(f)
    
    def _validate_config(self):
        """Validate critical configuration values"""
        # Check wallet configuration
        if self.wallet_private_key == "YOUR_PRIVATE_KEY_HERE":
            raise ValueError("Please set your private key in config.json")
        
        if self.rpc_url == "https://polygon-mainnet.g.alchemy.com/v2/YOUR_API_KEY":
            print("⚠️  WARNING: Using default RPC URL. Get your own Alchemy API key for better performance.")
        
        # Validate trading mode
        if self.trading_mode not in ["paper", "live"]:
            raise ValueError("Trading mode must be 'paper' or 'live'")
        
        # Validate percentages
        if not (0 < self.position_size_percent <= 100):
            raise ValueError("Position size must be between 0 and 100%")
        
        if not (0 < self.max_slippage_percent <= 50):
            raise ValueError("Max slippage must be between 0 and 50%")
    
    # Wallet settings
    @property
    def wallet_private_key(self):
        return self.config['wallet']['private_key']
    
    @property
    def wallet_address(self):
        return self.config['wallet']['address']
    
    # Network settings
    @property
    def rpc_url(self):
        return self.config['network']['rpc_url']
    
    @property
    def chain_id(self):
        return self.config['network']['chain_id']
    
    @property
    def gas_price_gwei(self):
        return self.config['network']['gas_price_gwei']
    
    @property
    def gas_limit(self):
        return self.config['network']['gas_limit']
    
    # DEX settings
    @property
    def quickswap_router(self):
        return self.config['dex']['quickswap_router']
    
    @property
    def quickswap_factory(self):
        return self.config['dex']['quickswap_factory']
    
    @property
    def uniswap_router(self):
        return self.config['dex']['uniswap_v2_router']
    
    @property
    def wmatic_address(self):
        return self.config['dex']['wmatic_address']
    
    @property
    def usdc_address(self):
        return self.config['dex']['usdc_address']
    
    # Trading settings
    @property
    def trading_mode(self):
        return self.config['trading']['mode']
    
    @property
    def min_liquidity_usd(self):
        return self.config['trading']['min_liquidity_usd']
    
    @property
    def max_liquidity_usd(self):
        return self.config['trading']['max_liquidity_usd']
    
    @property
    def position_size_percent(self):
        return self.config['trading']['position_size_percent']
    
    @property
    def max_slippage_percent(self):
        return self.config['trading']['max_slippage_percent']
    
    @property
    def min_score_threshold(self):
        return self.config['trading']['min_score_threshold']
    
    # Profit strategy
    @property
    def take_profit_3x(self):
        return self.config['profit_strategy']['take_profit_3x']
    
    @property
    def take_profit_5x(self):
        return self.config['profit_strategy']['take_profit_5x']
    
    @property
    def take_profit_10x(self):
        return self.config['profit_strategy']['take_profit_10x']
    
    @property
    def trailing_stop_percent(self):
        return self.config['profit_strategy']['trailing_stop_percent']
    
    @property
    def max_hold_time_minutes(self):
        return self.config['profit_strategy']['max_hold_time_minutes']
    
    # Safety settings
    @property
    def check_honeypot(self):
        return self.config['safety']['check_honeypot']
    
    @property
    def check_mint_function(self):
        return self.config['safety']['check_mint_function']
    
    @property
    def check_blacklist_function(self):
        return self.config['safety']['check_blacklist_function']
    
    @property
    def min_holders(self):
        return self.config['safety']['min_holders']
    
    @property
    def max_buy_tax(self):
        return self.config['safety']['max_buy_tax']
    
    @property
    def max_sell_tax(self):
        return self.config['safety']['max_sell_tax']
    
    # Scanning settings
    @property
    def scan_interval_seconds(self):
        return self.config['scanning']['interval_seconds']
    
    @property
    def lookback_blocks(self):
        return self.config['scanning']['lookback_blocks']
    
    @property
    def min_age_seconds(self):
        return self.config['scanning']['min_age_seconds']
    
    @property
    def max_age_seconds(self):
        return self.config['scanning']['max_age_seconds']
    
    # Logging settings
    @property
    def log_level(self):
        return self.config['logging']['level']
    
    @property
    def log_to_file(self):
        return self.config['logging']['log_to_file']
    
    @property
    def log_folder(self):
        return self.config['logging']['log_folder']
    
    def is_paper_trading(self):
        """Check if running in paper trading mode"""
        return self.trading_mode == "paper"
    
    def is_live_trading(self):
        """Check if running in live trading mode"""
        return self.trading_mode == "live"
